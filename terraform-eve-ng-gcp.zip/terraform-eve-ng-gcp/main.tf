provider "google" {
  project = var.project_id
  region  = var.region
  zone    = var.zone
}

resource "google_compute_instance" "eve_ng" {
  name         = "eve-ng-vm"
  machine_type = "n2-standard-16"
  zone         = var.zone

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size  = 200
      type  = "pd-ssd"
    }
  }

  network_interface {
    network       = "default"
    access_config {}
  }

  metadata = {
    enable-oslogin = "TRUE"
  }

  tags = ["http-server", "https-server", "eve-ng"]
}